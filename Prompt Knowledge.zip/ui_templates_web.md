# UI PROMPT TEMPLATES — WEB INTERFACES

Use these templates to generate highly detailed prompts for designing or coding web UIs.

1. "Act as a Senior UI/UX Designer and Frontend Architect. Design a responsive web dashboard for {{APP_TYPE}}. 
   Include: layout description (header, sidebar, main content, footer), component list, interaction patterns, 
   empty/error/loading states, and accessibility considerations. Also suggest a color palette and typography scale."

2. "Act as a Product Designer. Design a multi-step signup and onboarding flow for a web app that does {{FUNCTION}}. 
   Describe each step, form fields, validation, error states, progress indicator, and ways to reduce friction and drop-off."

3. "Act as a UX Researcher. Propose 3 alternative navigation patterns for a complex web app with {{N}} main sections. 
   Compare top navigation + sidebar, mega menu, and collapsible sidebar. For each, describe pros, cons, and best use case."

4. "Act as a UI Designer. Create a component library spec for a modern web app, including: buttons (all states), inputs, 
   dropdowns, modals, cards, tabs, tooltips, alerts, toasts, and data tables. Describe styles, spacing, and usage rules."

5. "Act as a Frontend Developer. Generate semantic HTML structure (without CSS) for a landing page for {{PRODUCT}}. 
   Include hero section, features, testimonials, pricing table, FAQ, and CTA sections with proper headings and structure."

6. "Act as a UI/UX Designer. Design a dark-mode-first web UI for a dashboard showing {{DATA_TYPE}}. 
   Detail card layouts, chart placements, filtering controls, and how to visually differentiate priorities and alerts."

7. "Act as a UX Writer. Write microcopy for buttons, placeholders, tooltips, error messages, and empty states 
   for a web app that does {{FEATURE_SET}}. Tone: {{TONE}}."

8. "Act as an Accessibility Specialist. Review the following UI description for accessibility concerns and 
   propose improvements related to color contrast, keyboard navigation, ARIA labels, and focus management: {{UI_DESCRIPTION}}."

9. "Act as a Design Systems Expert. Define a token-based design system for a web app, including color tokens, 
   typography tokens, spacing scale, border radius, and elevation levels. Provide naming conventions and usage examples."

10. "Act as a Product & UX Designer. Design a responsive table experience for large datasets on the web. 
    Include: column selection, horizontal scrolling, sorting, filtering, pagination vs infinite scroll, and mobile adaptations."

(You can reuse and adapt these formats across many specific UI scenarios.)