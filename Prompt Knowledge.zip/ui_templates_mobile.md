# UI PROMPT TEMPLATES — MOBILE INTERFACES

Use these templates to generate detailed prompts for mobile app UX/UI across iOS, Android, and cross-platform.

1. "Act as a Mobile Product Designer. Design the core navigation and key screens for a mobile app that does {{FUNCTION}}. 
   Include: navigation pattern choice (tab bar, drawer, bottom sheet, etc.), main screens, key CTAs, and gesture usage."

2. "Act as a UX Designer. Design the onboarding experience for a mobile app targeting first-time users of {{DOMAIN}}. 
   Include: intro screens, permission prompts strategy, progressive disclosure of features, and how to avoid overwhelming users."

3. "Act as a UI Designer. Provide a visual layout description for a mobile home screen that displays {{CONTENT_TYPE}}. 
   Specify grid/list choices, spacing, typography hierarchy, image usage, and card designs."

4. "Act as a Mobile UX Specialist. Design an offline-first experience for a mobile app where {{OFFLINE_USE_CASE}}. 
   Include: offline states, sync indicators, conflict resolution patterns, and user reassurance messaging."

5. "Act as a UX Writer. Write all key microcopy for a mobile checkout flow, including CTAs, helper text, 
   form labels, error messages, and success confirmation screens. Tone: {{TONE}}."

6. "Act as a Gesture Interaction Designer. Describe how swipe, long-press, pull-to-refresh, and drag-and-drop 
   can be used effectively in a mobile app for {{CONTEXT}} without making the UI confusing."

7. "Act as a Mobile UI Designer. Create design guidance for light mode vs dark mode in a mobile app for {{APP_TYPE}}. 
   Include: color choices, elevation/shadow adaptation, and safe contrast ratios."

8. "Act as a UX Researcher. Suggest usability testing scenarios and tasks to evaluate a new mobile app that does {{FUNCTION}}. 
   Include: participant profile, tasks, success metrics, and what to observe."

9. "Act as a Product Designer. Design a mobile notifications strategy for {{APP_TYPE}}. 
   Include: types of notifications, frequency rules, user controls, and examples of notification copy that feels helpful, not spammy."

10. "Act as a Design Systems Specialist. Define reusable mobile components for {{PLATFORM}} (e.g., cards, chips, FABs, 
    bottom sheets, carousels) and describe their behavior, states, and usage guidelines."