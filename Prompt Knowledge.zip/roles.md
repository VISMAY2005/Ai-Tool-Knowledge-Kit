# AVAILABLE ROLES FOR PROMPT GENERATION (EXTENDED)

Below is an extended list of expert roles that users can choose from when generating a prompt.
These roles help define the AI's perspective, expertise, and style.

## Technology & Engineering
1. Senior Full-Stack Developer
2. Backend Engineer (Node.js)
3. Backend Engineer (Python/Django)
4. Backend Engineer (Java/Spring)
5. Frontend Engineer (React)
6. Frontend Engineer (Vue)
7. Frontend Engineer (Angular)
8. Mobile App Developer (Android)
9. Mobile App Developer (iOS/Swift)
10. Mobile App Developer (Flutter)
11. UI/UX Designer
12. Product Designer
13. Interaction Designer
14. Design Systems Specialist
15. DevOps Engineer
16. Cloud Architect (AWS)
17. Cloud Architect (Azure)
18. Cloud Architect (GCP)
19. Site Reliability Engineer
20. Cybersecurity Analyst
21. Security Engineer (AppSec)
22. Network Security Architect
23. Blockchain Developer (Smart Contracts)
24. Web3 Developer
25. Embedded Systems Engineer
26. IoT Architect
27. Robotics Engineer
28. Game Developer (Unity)
29. Game Developer (Unreal Engine)
30. AR/VR Developer
31. Performance Optimization Engineer
32. Database Administrator (SQL)
33. NoSQL Database Specialist
34. Data Engineer
35. Data Scientist
36. Machine Learning Engineer
37. MLOps Engineer
38. Computer Vision Engineer
39. NLP Engineer
40. AI Researcher
41. Algorithm Engineer
42. Systems Programmer (C/C++)
43. Low-Level Firmware Engineer
44. API Architect
45. Integration Engineer
46. QA Engineer (Manual Testing)
47. QA Engineer (Automation)
48. Test Architect
49. Software Architect
50. Technical Lead / Engineering Manager

## Business, Product & Strategy
51. Product Manager (B2C)
52. Product Manager (B2B/SaaS)
53. Growth Product Manager
54. Business Analyst
55. Strategy Consultant
56. Management Consultant
57. Startup Advisor
58. VC/Investment Analyst
59. Operations Manager
60. Customer Success Manager
61. Technical Program Manager
62. Project Manager (Agile/Scrum)
63. Scrum Master
64. Lean/Process Improvement Specialist
65. OKR/Goal-Setting Coach

## Marketing & Sales
66. Digital Marketing Specialist
67. Performance Marketer
68. SEO Specialist
69. SEM/PPC Campaign Manager
70. Content Marketer
71. Social Media Manager
72. Brand Strategist
73. Email Marketing Specialist
74. Funnel Optimization Expert
75. Conversion Rate Optimization (CRO) Specialist
76. Copywriter (Sales Pages)
77. Copywriter (Ads)
78. Copywriter (Technical)
79. Community Manager
80. Influencer Marketing Strategist
81. Product Marketing Manager
82. Sales Strategist (B2B)
83. Sales Strategist (B2C)
84. Account Executive
85. Lead Generation Specialist

## Finance & Economics
86. Financial Analyst
87. Investment Advisor
88. Portfolio Manager
89. Risk Management Specialist
90. Corporate Finance Expert
91. Tax Consultant
92. Accountant (IFRS/GAAP)
93. Financial Planner
94. Crypto/DeFi Analyst
95. Economist (Macroeconomics)
96. Economist (Microeconomics)

## Legal & Compliance
97. Corporate Lawyer
98. Contract Drafting Specialist
99. Intellectual Property Lawyer
100. Privacy & Data Protection Expert
101. Compliance Officer
102. Employment Law Specialist
103. Terms & Conditions Drafting Expert
104. Policy & Governance Consultant

## Health, Fitness & Lifestyle
105. General Medical Advisor
106. Specialist Doctor (e.g., Cardiologist) – generic template
107. Physiotherapist
108. Nutritionist
109. Diet Planner
110. Fitness Coach (General)
111. Strength & Conditioning Coach
112. Yoga Instructor
113. Mental Health Counselor
114. Life Coach
115. Sleep Optimization Coach
116. Habit-Building Coach
117. Productivity Coach

## Education & Learning
118. School Teacher (K–12)
119. University Professor
120. Online Course Designer
121. Education Content Creator
122. Exam Strategy Coach
123. Language Tutor (English)
124. Language Tutor (Any Language – generic)
125. Study Skills Coach

## Writing, Media & Creativity
126. Novelist / Story Writer
127. Screenwriter (Film/TV)
128. Short Story Writer
129. Plot Development Consultant
130. Editor & Proofreader
131. Journalist
132. Blog Writer
133. Technical Writer
134. Scriptwriter (YouTube)
135. Scriptwriter (TikTok/Reels)
136. Podcast Producer
137. Documentary Writer
138. Comedy Writer
139. Ghostwriter

## Design & Multimedia
140. Graphic Designer
141. Brand Identity Designer
142. Logo Designer
143. Poster/Flyer Designer
144. Social Media Creative Designer
145. Motion Graphics Designer
146. 3D Artist
147. Video Editor
148. Color Grading Specialist
149. Thumbnail Designer (YouTube)

## Gaming & Worldbuilding
150. Game Narrative Designer
151. Game Systems Designer
152. Level Designer
153. Game Balance Specialist
154. Worldbuilding Consultant
155. Quest/Scenario Designer
156. Tabletop RPG Game Master
157. Character Designer (Narrative)

## Miscellaneous / Meta Roles
158. Prompt Engineer
159. Meta-Prompt Designer (for AI systems)
160. AI Safety & Alignment Advisor
161. UX Researcher
162. Customer Interview Specialist
163. Documentation Specialist
164. Knowledge Base Architect
165. Workshop Facilitator
166. Brainstorming Partner
167. Idea Validation Expert
168. Innovation Consultant
169. Change Management Specialist
170. Organizational Psychologist
171. Career Coach
172. Interview Preparation Coach
173. Resume & LinkedIn Optimization Expert
174. Public Speaking Coach
175. Presentation Design Specialist

(You may extend this file further in the future by appending more roles.)