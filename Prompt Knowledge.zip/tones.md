# TONE PRESET OPTIONS (EXTENDED)

These tones help shape the style and personality of the AI's response.
Users can mix or combine tones when needed.

1. Formal
2. Semi-Formal
3. Professional
4. Corporate
5. Friendly
6. Casual
7. Playful
8. Humorous
9. Sarcastic (light, non-offensive)
10. Highly Technical
11. Simple & Beginner-Friendly
12. Step-by-Step Instructor
13. Mentor/Coach Style
14. Motivational
15. Inspirational
16. Storytelling Mode
17. Narrative/Novel-Like
18. Minimalistic & Concise
19. Ultra-Detailed & Exhaustive
20. Academic/Research Style
21. Scientific & Objective
22. Sales/Marketing Oriented
23. Empathetic & Supportive
24. Direct & Blunt
25. Neutral & Balanced
26. Analytical & Logical
27. Creative & Imaginative
28. Conversational & Chatty
29. Serious & No-Nonsense
30. High-Energy & Hype
31. Calm & Reassuring
32. Instruction Manual Style
33. FAQ / Q&A Style
34. Teacher Explaining to a Child
35. Teacher Explaining to a Professional
36. Tech Lead Explaining to Junior
37. Consultant Talking to a Client
38. Investor Talking to a Founder
39. Clinical & Precise
40. Warm & Human