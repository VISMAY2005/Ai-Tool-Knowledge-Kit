# BEST PRACTICES FOR WRITING POWERFUL PROMPTS

This guide is included so Prompt Master 1.0 can reference and embed best practices
into the generated prompts or explain them to users when needed.

---

## 1. Always Define a Role

Giving the AI a clear role dramatically improves quality and consistency.

Examples:
- "Act as a Senior Full-Stack Developer..."
- "You are a Professional Scriptwriter..."
- "You are an Academic Researcher in Machine Learning..."

The role sets expectations for vocabulary, style, depth, and examples.

---

## 2. Clarify the Objective in One Sentence

Try to express the goal in a single, sharp sentence.

Examples:
- "Help me design a scalable backend for a ride-sharing app."
- "Write a YouTube script that explains XYZ to beginners."
- "Create a 30-day workout plan for muscle gain at home."

A strong objective helps the AI stay focused and relevant.

---

## 3. Provide Rich Context

Context is everything. Include:
- Current situation (e.g., "I already built X...")
- Existing constraints (budget, tools, skills, time)
- Examples of what you like or dislike
- Target platform or tech stack

The more relevant context, the less guessing the AI has to do.

---

## 4. Specify Tone and Style

Tell the AI exactly how to sound:
- Formal vs casual
- Simple vs technical
- Short vs detailed
- Fun vs serious

You can also combine tones:
- "Friendly but professional"
- "Technical yet beginner-friendly"

---

## 5. Add Specific Requirements

Specifics make outputs more usable:
- "Use bullet points."
- "Limit answer to 500 words."
- "Include at least 3 code examples."
- "Avoid jargon."
- "Use British English spelling."

Constraints act like guardrails.

---

## 6. Define the Audience

Knowing who it's for changes everything.

Examples:
- high-school students
- senior engineers
- non-technical managers
- beginner designers

Always specify the target audience if possible.

---

## 7. Request a Clear Output Format

Format determines how easy it is to use the result.

Examples:
- "Give the answer in a table with columns: Feature, Description, Priority."
- "Return a JSON object with fields: title, description, steps."
- "Provide numbered steps, each with a short explanation."

---

## 8. Use Iteration

The first output doesn't need to be the last.

Ask follow-ups like:
- "Make it shorter."
- "Add more examples."
- "Rewrite in simpler words."
- "Increase technical depth."
- "Adapt this for a mobile app context."

Iterative prompting + Prompt Master 1.0 = maximum quality.