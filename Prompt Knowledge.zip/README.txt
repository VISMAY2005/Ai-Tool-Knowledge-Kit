# Prompt Master 1.0 — Knowledge Pack

This folder contains knowledge files for the Prompt Master 1.0 system.
You can upload these files into your GPT's "Knowledge" section so it can
use them to generate powerful, structured prompts for users.

Included files:

- roles.md
- tones.md
- output_formats.md
- prompt_structure.txt
- prompting_guide.md
- prompt_templates_advanced.md
- ui_templates_web.md
- ui_templates_mobile.md

You can safely extend any of these files in the future by appending more content.